﻿"""
TCP Port Checker - Command line entry point
Allows running as: python -m tcp_port_checker
"""

from .main import main

if __name__ == "__main__":
    main()
